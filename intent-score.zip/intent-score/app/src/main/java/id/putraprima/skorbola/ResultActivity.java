package id.putraprima.skorbola;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        Intent intent = getIntent();

        String scoreA = intent.getStringExtra("Score home");
        String scoreB = intent.getStringExtra("Score away");
        TextView Score = findViewById(R.id.textView2);
        Score.setText(scoreA + " - " + scoreB);

        String Home = intent.getStringExtra("home");
        String Away = intent.getStringExtra("away");

        TextView txt_winner = findViewById(R.id.textView3);

        if (Integer.parseInt(scoreA) > Integer.parseInt(scoreB)) txt_winner.setText(Home + " Win");
        else if (Integer.parseInt(scoreA) < Integer.parseInt(scoreB)) txt_winner.setText(Away + " Win");
        else txt_winner.setText("Draw");
    }
}

