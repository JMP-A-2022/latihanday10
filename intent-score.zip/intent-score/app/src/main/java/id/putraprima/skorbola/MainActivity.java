package id.putraprima.skorbola;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //TODO
        //Fitur Main Activity
        //1. Validasi Input Home Team
        //2. Validasi Input Away Team
        //3. Ganti Logo Home Team
        //4. Ganti Logo Away Team
        //5. Next Button Pindah Ke MatchActivity
        final EditText home= findViewById(R.id.home_team);
        final EditText wayTeam= findViewById(R.id.away_team);
        Button next= findViewById(R.id.btn_team);

        next.setOnClickListener(v ->{
            String homee=home.getText().toString();
            String way=wayTeam.getText().toString();
            if(!homee.isEmpty()&&!way.isEmpty()){
                Intent intent = new Intent(MainActivity.this, MatchActivity.class);

                intent.putExtra("home", homee);
                intent.putExtra("away", way);

                startActivity(intent);
            }
        });
    }
}
